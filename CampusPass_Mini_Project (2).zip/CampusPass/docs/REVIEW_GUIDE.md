# CampusPass Review Guide

## 60-second introduction
Good morning. Our project is CampusPass – Student Opportunity & Achievement Passport. Students often store certificates, project details, and internship information in different places. CampusPass gives students one place to record achievements, upload proof, discover opportunities, and track their applications. Staff can review achievement proof and send feedback. We built it using Python, Django, PostgreSQL, HTML, CSS, Bootstrap, and JavaScript.

## Demo order
1. Home page and purpose.
2. Register a student and log in.
3. Complete the profile.
4. Add a sample achievement and upload dummy proof.
5. Show search/filter, edit/delete, and CSV export.
6. Log in as staff and approve/reject an achievement.
7. Return to the student account and show notification.
8. Browse opportunities, track an application, and show dashboard counts.
9. Show PostgreSQL tables/admin, migrations, and ER diagram.

## Explain these concepts
- Django model: Python class representing a database table.
- ORM: Lets Python code query and update the database without writing SQL for every operation.
- Migration: Versioned change that creates/updates database schema.
- Authentication: Confirms who logged in.
- Authorization: Limits actions based on permissions/role.
- CRUD: Create, Read, Update, Delete.
- CSRF token: Protects POST forms against cross-site request forgery.
- Pagination: Splits long lists into smaller pages.
- Unique constraint: Stops one student from tracking the same opportunity more than once.
- Additional features: dashboard statistics, proof upload and review, notifications, opportunity tracking, CSV export.

## Be transparent
- The “Track this opportunity” feature records the opportunity in CampusPass. It does not automatically submit an external organization's form.
- Use dummy/sample files and data during the demonstration.
- Test the app on the actual laptop and database before the review.
