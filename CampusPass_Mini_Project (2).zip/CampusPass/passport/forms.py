from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import StudentProfile, Achievement, Opportunity

class RegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=150, required=True)
    class Meta:
        model = User
        fields = ("username", "first_name", "email", "password1", "password2")

class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ("department", "year_of_study", "phone", "skills", "bio")
        widgets = {"bio": forms.Textarea(attrs={"rows": 3}), "skills": forms.TextInput(attrs={"placeholder": "Python, Django, SQL"})}

class AchievementForm(forms.ModelForm):
    class Meta:
        model = Achievement
        fields = ("title", "category", "organization", "date_earned", "description", "proof_file")
        widgets = {"date_earned": forms.DateInput(attrs={"type": "date"}), "description": forms.Textarea(attrs={"rows": 3})}

class OpportunityForm(forms.ModelForm):
    class Meta:
        model = Opportunity
        fields = ("title", "opportunity_type", "organization", "description", "eligibility", "application_url", "deadline", "is_active")
        widgets = {"deadline": forms.DateInput(attrs={"type": "date"}), "description": forms.Textarea(attrs={"rows": 4})}
