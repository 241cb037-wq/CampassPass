from django.conf import settings
from django.db import models
from django.utils import timezone

class StudentProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="student_profile")
    department = models.CharField(max_length=100, blank=True)
    year_of_study = models.PositiveSmallIntegerField(default=1)
    phone = models.CharField(max_length=20, blank=True)
    skills = models.CharField(max_length=500, blank=True)
    bio = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} profile"

class Achievement(models.Model):
    CATEGORY_CHOICES = [
        ("CERTIFICATE", "Certificate"),
        ("INTERNSHIP", "Internship"),
        ("PROJECT", "Project"),
        ("WORKSHOP", "Workshop"),
        ("AWARD", "Award"),
        ("OTHER", "Other"),
    ]
    STATUS_CHOICES = [
        ("PENDING", "Pending verification"),
        ("APPROVED", "Verified"),
        ("REJECTED", "Needs correction"),
    ]
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="achievements")
    title = models.CharField(max_length=160)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    organization = models.CharField(max_length=160, blank=True)
    date_earned = models.DateField(null=True, blank=True)
    description = models.TextField(blank=True)
    proof_file = models.FileField(upload_to="achievement_proofs/", blank=True, null=True)
    verification_status = models.CharField(max_length=12, choices=STATUS_CHOICES, default="PENDING")
    reviewer_note = models.CharField(max_length=300, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["student", "category"]), models.Index(fields=["verification_status"])]

    def __str__(self):
        return f"{self.title} - {self.student.username}"

class Opportunity(models.Model):
    TYPE_CHOICES = [
        ("INTERNSHIP", "Internship"),
        ("WORKSHOP", "Workshop"),
        ("HACKATHON", "Hackathon"),
        ("COMPETITION", "Competition"),
        ("PLACEMENT", "Placement"),
        ("OTHER", "Other"),
    ]
    title = models.CharField(max_length=180)
    opportunity_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    organization = models.CharField(max_length=160)
    description = models.TextField()
    eligibility = models.CharField(max_length=300, blank=True)
    application_url = models.URLField(blank=True)
    deadline = models.DateField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    posted_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="posted_opportunities")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["deadline", "-created_at"]

    def __str__(self):
        return self.title

class OpportunityApplication(models.Model):
    STATUS_CHOICES = [
        ("APPLIED", "Applied"),
        ("SHORTLISTED", "Shortlisted"),
        ("SELECTED", "Selected"),
        ("REJECTED", "Not selected"),
        ("WITHDRAWN", "Withdrawn"),
    ]
    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="opportunity_applications")
    opportunity = models.ForeignKey(Opportunity, on_delete=models.CASCADE, related_name="applications")
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default="APPLIED")
    applied_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["student", "opportunity"], name="unique_student_opportunity_application")]
        ordering = ["-applied_at"]

    def __str__(self):
        return f"{self.student.username} - {self.opportunity.title}"

class Notification(models.Model):
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="campus_notifications")
    message = models.CharField(max_length=250)
    link = models.CharField(max_length=250, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Notification for {self.recipient.username}"
