document.addEventListener("DOMContentLoaded", () => {
  // Add Bootstrap styling to Django-generated form controls.
  document.querySelectorAll("input:not([type=checkbox]):not([type=radio]):not([type=file]), textarea").forEach(el => el.classList.add("form-control"));
  document.querySelectorAll("select").forEach(el => el.classList.add("form-select"));
  document.querySelectorAll("input[type=file]").forEach(el => el.classList.add("form-control"));
  // Prevent accidental double-submission of forms with submit buttons.
  document.querySelectorAll("form").forEach(form => form.addEventListener("submit", () => {
    const button = form.querySelector("button[type=submit], button:not([type])");
    if (button && !button.dataset.allowRepeat) {
      button.dataset.allowRepeat = "true";
      button.dataset.originalText = button.textContent;
      button.disabled = true;
      button.textContent = "Please wait…";
    }
  }));
});
