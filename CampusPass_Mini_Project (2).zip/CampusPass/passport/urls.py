from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("register/", views.register, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="registration/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/edit/", views.profile_edit, name="profile_edit"),
    path("achievements/", views.achievement_list, name="achievement_list"),
    path("achievements/add/", views.achievement_create, name="achievement_create"),
    path("achievements/<int:pk>/edit/", views.achievement_edit, name="achievement_edit"),
    path("achievements/<int:pk>/delete/", views.achievement_delete, name="achievement_delete"),
    path("achievements/export/csv/", views.export_achievements_csv, name="export_achievements_csv"),
    path("opportunities/", views.opportunity_list, name="opportunity_list"),
    path("opportunities/add/", views.opportunity_create, name="opportunity_create"),
    path("opportunities/<int:pk>/apply/", views.opportunity_apply, name="opportunity_apply"),
    path("applications/", views.my_applications, name="my_applications"),
    path("applications/<int:pk>/withdraw/", views.application_withdraw, name="application_withdraw"),
    path("notifications/", views.notifications_list, name="notifications"),
    path("staff/achievements/", views.admin_achievements, name="admin_achievements"),
    path("staff/achievements/<int:pk>/review/", views.achievement_review, name="achievement_review"),
]
