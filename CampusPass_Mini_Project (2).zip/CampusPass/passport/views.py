import csv
from datetime import date
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import User
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from .forms import RegistrationForm, StudentProfileForm, AchievementForm, OpportunityForm
from .models import StudentProfile, Achievement, Opportunity, OpportunityApplication, Notification

def home(request):
    opportunities = Opportunity.objects.filter(is_active=True).order_by("deadline")[:3]
    return render(request, "passport/home.html", {"opportunities": opportunities})

def register(request):
    if request.user.is_authenticated:
        return redirect("dashboard")
    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        StudentProfile.objects.create(user=user)
        login(request, user)
        messages.success(request, "Welcome to CampusPass! Your account is ready.")
        return redirect("dashboard")
    return render(request, "registration/register.html", {"form": form})

@login_required
def dashboard(request):
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    achievements = Achievement.objects.filter(student=request.user)
    applications = OpportunityApplication.objects.filter(student=request.user).select_related("opportunity")
    notifications = Notification.objects.filter(recipient=request.user, is_read=False)[:5]
    context = {
        "profile": profile,
        "total_achievements": achievements.count(),
        "verified_achievements": achievements.filter(verification_status="APPROVED").count(),
        "pending_achievements": achievements.filter(verification_status="PENDING").count(),
        "applications_count": applications.count(),
        "recent_achievements": achievements[:5],
        "recent_applications": applications[:5],
        "notifications": notifications,
        "upcoming_opportunities": Opportunity.objects.filter(is_active=True, deadline__gte=date.today()).order_by("deadline")[:4],
    }
    return render(request, "passport/dashboard.html", context)

@login_required
def profile_edit(request):
    profile, _ = StudentProfile.objects.get_or_create(user=request.user)
    form = StudentProfileForm(request.POST or None, instance=profile)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Profile updated.")
        return redirect("dashboard")
    return render(request, "passport/form_page.html", {"form": form, "page_title": "Edit student profile", "button_text": "Save profile"})

@login_required
def achievement_list(request):
    items = Achievement.objects.filter(student=request.user)
    query = request.GET.get("q", "").strip()
    category = request.GET.get("category", "").strip()
    status = request.GET.get("status", "").strip()
    if query:
        items = items.filter(Q(title__icontains=query) | Q(organization__icontains=query) | Q(description__icontains=query))
    if category:
        items = items.filter(category=category)
    if status:
        items = items.filter(verification_status=status)
    from django.core.paginator import Paginator
    page_obj = Paginator(items, 6).get_page(request.GET.get("page"))
    return render(request, "passport/achievement_list.html", {"page_obj": page_obj, "q": query, "category": category, "status": status, "categories": Achievement.CATEGORY_CHOICES, "statuses": Achievement.STATUS_CHOICES})

@login_required
def achievement_create(request):
    form = AchievementForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        achievement = form.save(commit=False)
        achievement.student = request.user
        achievement.save()
        messages.success(request, "Achievement added and sent for verification.")
        return redirect("achievement_list")
    return render(request, "passport/form_page.html", {"form": form, "page_title": "Add achievement", "button_text": "Save achievement"})

@login_required
def achievement_edit(request, pk):
    item = get_object_or_404(Achievement, pk=pk, student=request.user)
    if item.verification_status == "APPROVED":
        messages.error(request, "Verified achievements cannot be edited. Contact an administrator if a correction is needed.")
        return redirect("achievement_list")
    form = AchievementForm(request.POST or None, request.FILES or None, instance=item)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.verification_status = "PENDING"
        item.reviewer_note = ""
        item.save()
        messages.success(request, "Achievement updated and sent for verification.")
        return redirect("achievement_list")
    return render(request, "passport/form_page.html", {"form": form, "page_title": "Edit achievement", "button_text": "Update achievement"})

@login_required
def achievement_delete(request, pk):
    item = get_object_or_404(Achievement, pk=pk, student=request.user)
    if request.method == "POST":
        item.delete()
        messages.success(request, "Achievement deleted.")
        return redirect("achievement_list")
    return render(request, "passport/confirm_delete.html", {"item": item, "page_title": "Delete achievement"})

@login_required
def opportunity_list(request):
    items = Opportunity.objects.filter(is_active=True)
    query = request.GET.get("q", "").strip()
    kind = request.GET.get("type", "").strip()
    if query:
        items = items.filter(Q(title__icontains=query) | Q(organization__icontains=query) | Q(description__icontains=query))
    if kind:
        items = items.filter(opportunity_type=kind)
    from django.core.paginator import Paginator
    page_obj = Paginator(items, 6).get_page(request.GET.get("page"))
    applied_ids = set(OpportunityApplication.objects.filter(student=request.user).values_list("opportunity_id", flat=True)) if request.user.is_authenticated else set()
    return render(request, "passport/opportunity_list.html", {"page_obj": page_obj, "q": query, "kind": kind, "types": Opportunity.TYPE_CHOICES, "applied_ids": applied_ids})

@login_required
def opportunity_apply(request, pk):
    if request.method != "POST":
        return redirect("opportunity_list")
    opportunity = get_object_or_404(Opportunity, pk=pk, is_active=True)
    if opportunity.deadline and opportunity.deadline < date.today():
        messages.error(request, "The deadline for this opportunity has passed.")
        return redirect("opportunity_list")
    application, created = OpportunityApplication.objects.get_or_create(student=request.user, opportunity=opportunity)
    if created:
        messages.success(request, "Application saved to your CampusPass dashboard.")
        if opportunity.application_url:
            messages.info(request, "Use the opportunity's official application link to complete any external application.")
    else:
        messages.info(request, "You have already saved an application for this opportunity.")
    return redirect("my_applications")

@login_required
def my_applications(request):
    applications = OpportunityApplication.objects.filter(student=request.user).select_related("opportunity")
    return render(request, "passport/applications.html", {"applications": applications})

@login_required
def application_withdraw(request, pk):
    application = get_object_or_404(OpportunityApplication, pk=pk, student=request.user)
    if request.method == "POST":
        application.status = "WITHDRAWN"
        application.save(update_fields=["status"])
        messages.success(request, "Application marked as withdrawn.")
    return redirect("my_applications")

@login_required
def export_achievements_csv(request):
    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = 'attachment; filename="campuspass_achievements.csv"'
    writer = csv.writer(response)
    writer.writerow(["Title", "Category", "Organization", "Date Earned", "Verification Status", "Description"])
    for item in Achievement.objects.filter(student=request.user):
        writer.writerow([item.title, item.get_category_display(), item.organization, item.date_earned or "", item.get_verification_status_display(), item.description])
    return response

def staff_check(user):
    return user.is_staff

@login_required
@user_passes_test(staff_check)
def admin_achievements(request):
    items = Achievement.objects.select_related("student").all()
    status = request.GET.get("status", "PENDING")
    if status in dict(Achievement.STATUS_CHOICES):
        items = items.filter(verification_status=status)
    return render(request, "passport/admin_achievements.html", {"items": items, "status": status, "statuses": Achievement.STATUS_CHOICES})

@login_required
@user_passes_test(staff_check)
def achievement_review(request, pk):
    item = get_object_or_404(Achievement, pk=pk)
    if request.method == "POST":
        action = request.POST.get("action")
        note = request.POST.get("reviewer_note", "").strip()
        if action in ("APPROVED", "REJECTED"):
            item.verification_status = action
            item.reviewer_note = note[:300]
            item.save(update_fields=["verification_status", "reviewer_note"])
            Notification.objects.create(
                recipient=item.student,
                message=f"Your achievement '{item.title}' was {'verified' if action == 'APPROVED' else 'returned for correction'}.",
                link="/achievements/",
            )
            messages.success(request, "Review saved and student notified.")
    return redirect("admin_achievements")

@login_required
def notifications_list(request):
    items = Notification.objects.filter(recipient=request.user)
    if request.method == "POST":
        items.filter(is_read=False).update(is_read=True)
        messages.success(request, "Notifications marked as read.")
        return redirect("notifications")
    return render(request, "passport/notifications.html", {"notifications": items})

@login_required
def opportunity_create(request):
    if not request.user.is_staff:
        return redirect("dashboard")
    form = OpportunityForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        opportunity = form.save(commit=False)
        opportunity.posted_by = request.user
        opportunity.save()
        messages.success(request, "Opportunity published.")
        return redirect("opportunity_list")
    return render(request, "passport/form_page.html", {"form": form, "page_title": "Post an opportunity", "button_text": "Publish opportunity"})
