from django.contrib import admin
from .models import StudentProfile, Achievement, Opportunity, OpportunityApplication, Notification

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "department", "year_of_study")
    search_fields = ("user__username", "user__email", "department")

@admin.register(Achievement)
class AchievementAdmin(admin.ModelAdmin):
    list_display = ("title", "student", "category", "verification_status", "created_at")
    list_filter = ("category", "verification_status")
    search_fields = ("title", "student__username", "organization")
    readonly_fields = ("created_at",)

@admin.register(Opportunity)
class OpportunityAdmin(admin.ModelAdmin):
    list_display = ("title", "organization", "opportunity_type", "deadline", "is_active")
    list_filter = ("opportunity_type", "is_active")
    search_fields = ("title", "organization")

@admin.register(OpportunityApplication)
class OpportunityApplicationAdmin(admin.ModelAdmin):
    list_display = ("student", "opportunity", "status", "applied_at")
    list_filter = ("status",)
    search_fields = ("student__username", "opportunity__title")

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("recipient", "message", "is_read", "created_at")
    list_filter = ("is_read",)
